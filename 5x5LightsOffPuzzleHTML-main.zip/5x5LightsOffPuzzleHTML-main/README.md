# 5x5LightsOffPuzzleHTML
Recreates the 5 x 5 Lights Off Puzzle in HTML and JavaScript.
